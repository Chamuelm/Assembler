/* 
 * File:    firstPass.h
 * Author:  Moshe Hamiel
 * ID:      308238716
 *
 * Contains function declarations of secondPass.c
 * 
 */

#ifndef SECONDPASS_H
#define SECONDPASS_H

void secondPass();

#endif /* SECONDPASS_H */

