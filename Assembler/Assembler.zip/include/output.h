/* 
 * File:    output.h
 * Author:  Moshe Hamiel
 * ID:      308238716
 *
 * Contains function declarations of output.c
 * 
 */
#ifndef OUTPUT_H
#define OUTPUT_H

void createOutputFiles();
void intToBase32STR(int num, char *dest);

#endif /* OUTPUT_H */

